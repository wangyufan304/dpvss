/*===========================================================================*/
/* SEED reader     |               free_all                |  station header */
/*===========================================================================*/
/*
	Name:		free_all
*/

#include "rdseed.h"

void free_all()
{

	free_type11();
	free_type12();
	free_type30();
	free_type31();
	free_type32();
	free_type33();
	free_type34();
	free_type35();
	free_type41();
	free_type42();
	free_type43();
	free_type44();
	free_type45();
	free_type46();
	free_type47();
	free_type48();
	free_type50();
	free_type70();
	free_type71();
	free_type72();
	free_type73();
	free_type74();

}
